package com.example.appt;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.view.Window;
import android.view.WindowManager;

import androidx.core.content.ContextCompat;
//Classe futura para o tema escuro nas duas telas

public class ThemeUtils {
    private static final String THEME_PREFERENCES = "ThemePreferences";
    private static final String KEY_THEME = "theme";

    public static void applyTheme(Context context) {
        int theme = getTheme(context);
        context.setTheme(theme);
    }

    public static int getTheme(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(THEME_PREFERENCES, Context.MODE_PRIVATE);
        return preferences.getInt(KEY_THEME, R.style.AppTheme_Light);
    }

    public static void setTheme(Context context, int theme) {
        SharedPreferences preferences = context.getSharedPreferences(THEME_PREFERENCES, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(KEY_THEME, theme);
        editor.apply();


        if (theme != R.style.AppTheme_Dark && theme != R.style.AppTheme_Light) {
            context.setTheme(R.style.AppTheme_Light);
        }
    }

    public static void applyDarkTheme(Context context) {
        setTheme(context, R.style.AppTheme_Dark);

        // Configurar a barra de status para corresponder ao tema escuro
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = ((Activity) context).getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(ContextCompat.getColor(context, R.color.dark_status_bar));
        }
        }
    }


