package com.example.appt;

import static com.example.appt.BancoDados.db;
import android.app.AlertDialog;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class TelaConsulta extends AppCompatActivity {

    TextView tv_paciente,tv_nome,tv_sexo,tv_telefone,tv_endereco,tv_medico,tv_titulo;
    EditText et_nome, et_telefone, et_endereco, et_medico;
    Button btn_anterior, btn_proximo, btn_voltar, button_call, btn_apagar;
    Spinner spinner_genero;
    Switch switchDark;
    Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
/*
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        boolean isDarkThemeEnabled = preferences.getBoolean("dark_theme_enabled", false);
        if (isDarkThemeEnabled) {
            ThemeUtils.applyTheme(this);
            ThemeUtils.applyDarkTheme(this);
        } else {
            ThemeUtils.applyDarkTheme(this);
        }

 */


        setContentView(R.layout.activity_tela_consulta);
        tv_paciente  = findViewById(R.id.tv_paciente);
        tv_nome= findViewById(R.id.tv_nome_consulta);
        tv_sexo = findViewById(R.id.tv_sexo_consulta);
        tv_telefone = findViewById(R.id.tv_telefone_consulta);
        tv_endereco = findViewById(R.id.tv_endereco_consulta);
        tv_medico = findViewById(R.id.tv_medico_consulta);
        tv_titulo=findViewById(R.id.tv_titulo_consulta);
        et_nome = findViewById(R.id.et_nome_consulta);
        et_telefone = findViewById(R.id.et_telefone_consulta);
        et_endereco = findViewById(R.id.et_endereco_consulta);
        et_medico = findViewById(R.id.et_medico_consulta);
        btn_anterior = findViewById(R.id.btn_anterior);
        btn_proximo = findViewById(R.id.btn_proximo);
        btn_voltar = findViewById(R.id.btn_voltar_consulta);
        button_call = findViewById(R.id.button_call);
        btn_apagar = findViewById(R.id.btn_apagar);
        spinner_genero = findViewById(R.id.spinner_genero);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.genero_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_genero.setAdapter(adapter);
        switchDark=findViewById(R.id.btDark2);
        // Desativa o click nos ET
        et_nome.setEnabled(false);
        et_telefone.setEnabled(false);
        et_endereco.setEnabled(false);
        et_medico.setEnabled(false);
        spinner_genero.setEnabled(false);

        cursor = BancoDados.buscarDados(this);
        if (cursor.getCount() != 0) {
            mostrarDados();
        } else {
            CxMsg.mostrar("Nenhum registro encontrado", this);
        }

        button_call.setOnClickListener(v -> {
            String phoneNumber = et_telefone.getText().toString();

            if (!phoneNumber.isEmpty()) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phoneNumber));
                startActivity(intent);
            } else {
                Toast.makeText(getApplicationContext(), "Nenhum número de telefone encontrado", Toast.LENGTH_SHORT).show();
            }
        });
        btn_apagar.setOnClickListener(v -> confirmarApagarContato());
        switchDark.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    setDarkTheme();
                } else {
                    setLightTheme();
                }
            }
        });
    }

    private void setDarkTheme() {
        getWindow().getDecorView().setBackgroundColor(getResources().getColor(R.color.black));
        tv_paciente.setTextColor(getResources().getColor(R.color.dark_text));
        tv_nome.setTextColor(getResources().getColor(R.color.dark_text));
        tv_sexo.setTextColor(getResources().getColor(R.color.dark_text));
        tv_telefone.setTextColor(getResources().getColor(R.color.dark_text));
        tv_endereco.setTextColor(getResources().getColor(R.color.dark_text));
        tv_medico.setTextColor(getResources().getColor(R.color.dark_text));
        tv_titulo.setTextColor(getResources().getColor(R.color.dark_text));
        et_nome.setTextColor(getResources().getColor(R.color.dark_text));
        et_telefone.setTextColor(getResources().getColor(R.color.dark_text));
        et_endereco.setTextColor(getResources().getColor(R.color.dark_text));
        et_medico.setTextColor(getResources().getColor(R.color.dark_text));
        btn_anterior.setTextColor(getResources().getColor(R.color.dark_text));
        btn_proximo.setTextColor(getResources().getColor(R.color.dark_text));
        btn_voltar.setTextColor(getResources().getColor(R.color.dark_text));
        button_call.setTextColor(getResources().getColor(R.color.dark_text));
        btn_apagar.setTextColor(getResources().getColor(R.color.dark_text));
        spinner_genero.setPopupBackgroundResource(R.color.dark_text);
        switchDark.setTextColor(getResources().getColor(R.color.dark_text));
        ((TextView) spinner_genero.getSelectedView()).setTextColor(getResources().getColor(R.color.dark_text));
    }
    private void setLightTheme() {
        getWindow().getDecorView().setBackgroundColor(getResources().getColor(R.color.white));
        switchDark.setTextColor(getResources().getColor(R.color.light_text));
        tv_paciente.setTextColor(getResources().getColor(R.color.light_text));
        tv_nome.setTextColor(getResources().getColor(R.color.light_text));
        tv_sexo.setTextColor(getResources().getColor(R.color.light_text));
        tv_telefone.setTextColor(getResources().getColor(R.color.light_text));
        tv_endereco.setTextColor(getResources().getColor(R.color.light_text));
        tv_medico.setTextColor(getResources().getColor(R.color.light_text));
        tv_titulo.setTextColor(getResources().getColor(R.color.light_text));
        et_nome.setTextColor(getResources().getColor(R.color.light_text));
        et_telefone.setTextColor(getResources().getColor(R.color.light_text));
        et_endereco.setTextColor(getResources().getColor(R.color.light_text));
        et_medico.setTextColor(getResources().getColor(R.color.light_text));
        btn_anterior.setTextColor(getResources().getColor(R.color.light_text));
        btn_proximo.setTextColor(getResources().getColor(R.color.light_text));
        btn_voltar.setTextColor(getResources().getColor(R.color.light_text));
        button_call.setTextColor(getResources().getColor(R.color.light_text));
        btn_apagar.setTextColor(getResources().getColor(R.color.light_text));
        spinner_genero.setPopupBackgroundResource(R.color.dark_text);
        ((TextView) spinner_genero.getSelectedView()).setTextColor(getResources().getColor(R.color.light_text));
    }
    private int getIndex(Spinner spinner, String value) {
        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(value)) {
                return i;
            }
        }
        return 0;
    }

    public void fechar_tela(View v) {
        this.finish();
    }

    public void proximoRegistro(View v) {
        try {
            cursor.moveToNext();
            mostrarDados();
        } catch (Exception ex) {
            if (cursor.isAfterLast()) {
                CxMsg.mostrar("Não existem mais registros", this);
            } else {
                CxMsg.mostrar("Erro ao navegar pelos registros", this);
            }
        }
    }

    public void registroAnterior(View v) {
        try {
            cursor.moveToPrevious();
            mostrarDados();
        } catch (Exception ex) {
            if (cursor.isBeforeFirst()) {
                CxMsg.mostrar("Não existem mais registros", this);
            } else {
                CxMsg.mostrar("Erro ao navegar pelos registros", this);
            }
        }
    }

    private void confirmarApagarContato() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Apagar Contato");
        builder.setMessage("Tem certeza de que deseja apagar este contato?");
        builder.setPositiveButton("Sim", (dialog, which) -> apagarContato());
        builder.setNegativeButton("Cancelar", null);
        builder.create().show();
    }

    private void apagarContato() {
        String nome = et_nome.getText().toString();
        BancoDados.abrirDB(this);
        try {
            db.delete("contatos", "nome=?", new String[]{nome});
            cursor = BancoDados.buscarDados(this);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                mostrarDados();
            } else {
                et_nome.setText("");
                et_telefone.setText("");
                et_endereco.setText("");
                et_medico.setText("");
                CxMsg.mostrar("Nenhum registro encontrado", this);
            }
        } catch (Exception ex) {
            CxMsg.mostrar("Erro ao apagar contato!", this);
        } finally {
            CxMsg.mostrar("Contato apagado com sucesso!", this);
        }
        BancoDados.fecharDB();
    }

    @SuppressLint("Range")
    public void mostrarDados() {
        et_nome.setText(cursor.getString(cursor.getColumnIndex("nome")));
        et_telefone.setText(cursor.getString(cursor.getColumnIndex("fone")));
        et_endereco.setText(cursor.getString(cursor.getColumnIndex("endereco")));
        et_medico.setText(cursor.getString(cursor.getColumnIndex("medico")));
        String genero = cursor.getString(cursor.getColumnIndex("genero"));
        spinner_genero.setSelection(getIndex(spinner_genero, genero));
    }
}
