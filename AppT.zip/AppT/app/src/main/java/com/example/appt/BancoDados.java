package com.example.appt;


import static android.content.Context.MODE_PRIVATE;

import android.app.Activity;
import android.content.ContextWrapper;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

public class BancoDados {
    static SQLiteDatabase db = null;
    static Cursor cursor;

    public static void abrirDB(Activity act) {
        try {
            ContextWrapper cw = (ContextWrapper) act.getBaseContext();
            db = cw.openOrCreateDatabase("Banco agenda", MODE_PRIVATE, null);
        } catch (Exception ex) {
            CxMsg.mostrar("Erro ao abrir ou ao criar banco de dados", act);
        }
    }

    public static void fecharDB() {
        db.close();
    }

    public static void abrirOuCriarTabela(Activity act) {
        try {
            db.execSQL("CREATE TABLE IF NOT EXISTS contatos(id INTEGER PRIMARY KEY, nome TEXT, fone TEXT, genero TEXT, medico TEXT, endereco TEXT)");

            // Verifica se a coluna "genero" já existe na tabela
            Cursor cursor = db.rawQuery("PRAGMA table_info(contatos)", null);
            boolean columnExists = false;
            int nameColumnIndex = cursor.getColumnIndex("name");
            while (cursor.moveToNext()) {
                String columnName = cursor.getString(nameColumnIndex);
                if (columnName.equals("genero")) {
                    columnExists = true;
                    break;
                }
            }
            cursor.close();

            if (!columnExists) {
                // Adicione a coluna "genero" à tabela
                db.execSQL("ALTER TABLE contatos ADD COLUMN genero TEXT");
            }

            // Verifica se a coluna "medico" já existe na tabela
            cursor = db.rawQuery("PRAGMA table_info(contatos)", null);
            columnExists = false;
            while (cursor.moveToNext()) {
                String columnName = cursor.getString(nameColumnIndex);
                if (columnName.equals("medico")) {
                    columnExists = true;
                    break;
                }
            }
            cursor.close();

            if (!columnExists) {
                // Adicione a coluna "medico" à tabela
                db.execSQL("ALTER TABLE contatos ADD COLUMN medico TEXT");
            }

            // Verifica se a coluna "endereco" já existe na tabela
            cursor = db.rawQuery("PRAGMA table_info(contatos)", null);
            columnExists = false;
            while (cursor.moveToNext()) {
                String columnName = cursor.getString(nameColumnIndex);
                if (columnName.equals("endereco")) {
                    columnExists = true;
                    break;
                }
            }
            cursor.close();

            if (!columnExists) {
                // Adicione a coluna "endereco" à tabela
                db.execSQL("ALTER TABLE contatos ADD COLUMN endereco TEXT");
            }
        } catch (Exception ex) {
            CxMsg.mostrar("Erro ao criar tabela", act);
        }
    }

    public static void inserirRegistro(String nome, String fone, String genero, String medico, String endereco, Activity act) {
        abrirDB(act);
        try {
            String query = "INSERT INTO contatos (nome, fone, genero, medico, endereco) VALUES ('" + nome + "','" + fone + "','" + genero + "','" + medico + "','" + endereco + "')";
            db.execSQL(query);
        } catch (Exception ex) {
            CxMsg.mostrar("Erro ao inserir registro!", act);
        } finally {
            CxMsg.mostrar("Registro inserido com sucesso!", act);
        }
        fecharDB();
    }

    public static Cursor buscarDados(Activity act) {
        abrirDB(act);
        cursor = db.query("contatos",
                new String[]{"nome", "fone", "genero", "medico", "endereco"},
                null, null, null, null, null, null);
        cursor.moveToFirst();
        return cursor;
    }
}
